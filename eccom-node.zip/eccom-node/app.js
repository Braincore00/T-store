 const express  = require('express')
 const app = express()
 const mongoose = require('mongoose')
 const bodyParser = require('body-parser')
 const session = require('express-session')
 const mongoDBstore = require('connect-mongodb-session')(session);
 const flash = require('connect-flash')
 const mongoDB_uri = 'mongodb+srv://braincore67:JCYG58zp1f3zRpWG@cluster0.9brfpvq.mongodb.net/tstor?retryWrites=true&w=majority&appName=Cluster0'
 
 const store = new mongoDBstore({
   uri : mongoDB_uri,
   collection : "sessions",
 })


 
 const shopRoutes = require('./routes/shop')
 const adminRoutes = require('./routes/admin')
 const authRoutes = require('./routes/auth')
 const User = require('./models/user')
 
 
 
 app.set('view engine', 'ejs')
 app.use(express.static('public'))
 app.use('/uploads/images',express.static("uploads/images"))
 app.use(bodyParser.urlencoded({extended : false}))
 app.use(bodyParser.json())

 app.use(session({
   secret : 'its is secret key',
   resave : false,
   saveUninitialized : false,
   store : store,
 }))
app.use(flash())

 app.use((req, res, next)=>{
    res.locals.isAuthenticated = req.session.isloginedIn
 
      res.locals.isAdmin = req.session.role == 'admin'? true : false
      
 
   if(!req.session.isloginedIn){
      return next()
     
   }
   User.findById(req.session.user).then((user)=>{
      req.user = user
      next()
       
   }).catch((err)=> console.log(err))
})
  


 

 


app.use(authRoutes)
app.use(shopRoutes)
app.use('/admin', adminRoutes)

mongoose.connect(mongoDB_uri).then(()=>{
   app.listen(3000, 'localhost', ()=>{
      console.log('app is runing');
   })

}).catch((err) => console.log(err))