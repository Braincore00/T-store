const mongoose = require('mongoose')

 const userSchema = new mongoose.Schema({
    username :{
        type : 'String',
        required : true,
    },
    email : {
        type : 'String',
        required : true,
        unique : true,
    },
    password : {
        type : 'String',
        required : true
    },
    role :{
        type : String,
        required : false,
    },
    resetToken : String,
    resetTokenExpiration : Date,
    cart :[ {
    productId : {
            type : 'String',
            ref : 'Product',
            required : true
        },
        quantity :{
            type : 'Number',
            required : true,
        }
    }
],
address :[{
    firstName :{
        type : 'String',
        required : true
    },
    lastName :{
        type : 'String',
        required : true
    },
    country :{
        type : 'String',
        required : false
    },
    street :{
        type : 'String',
        required : true
    },
    houseNo :{
        type : 'Number',
        required : false
    },
    city :{
        type : 'String',
        required : true
    },
    state :{
        type : 'String',
        required : true
    },
    pincode :{
        type : 'Number',
        required : true
    },
    phone :{
        type : 'Number',
        required : true
    },
    email :{
        type : 'String',
        required : true
    },
}]
 },{
    timestamps : true
 })

 userSchema.methods.addcart = function (prodId){
    // console.log(prodId);
    // console.log(this);
 const exitingProductId =  this.cart.findIndex((p)=>{
      return  p.productId.toString() === prodId
    })
    let updateCartItem = [...this.cart]
    if(exitingProductId >=0){
    updateCartItem[exitingProductId].quantity += 1
    }
    else{
    updateCartItem.push({productId : prodId, quantity : 1})
}
    
this.cart = updateCartItem
return this.save()
    
 }
 userSchema.methods.updateCartItem = function (prodId,qty){
    // console.log(prodId, qty);
   const exitingCartItem =  this.cart.findIndex((p)=>{
      return  p.productId.toString() === prodId
    })
    const updateCart = [...this.cart]
    updateCart[exitingCartItem].quantity += qty
    this.cart = updateCart
    return this.save() 

}

userSchema.methods.deleteProdFromCart = function (prodId){
//     console.log(prodId);
//  console.log(this.cart); 
 
const updateCart = this.cart.filter((p)=>{
   return p.productId.toString() !== prodId
 }) 
 this.cart = updateCart
 return this.save() 

}
userSchema.methods.clearCart= function (){
    this.cart =[]
   return this.save()
}
userSchema.methods.addAddress = function(address){
    // console.log(address);
    // console.log(this.address);
    let updateCartAddress = [...this.address]
    updateCartAddress.push(address)
    this.address = updateCartAddress
   return this.save()
}
const User =  mongoose.model('User',userSchema)
module.exports = User