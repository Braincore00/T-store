const mongoose = require('mongoose')

 

const OrderSchema = new  mongoose.Schema ({
    products: [
        {
        productData: {
            type: Object,
            required: true,
            ref: 'Product',
        },
        quantity: {
            type: 'Number',
            required: true,
        },
    },
],
    address: {
        type: Object,
        required: true,
        ref: 'User'
    },
    userId: {
        type :  mongoose.Schema.Types.ObjectId,
        required: true,
        ref: 'User'
    },

}, { timestamps: true })

 module.exports  = mongoose.model('Order', OrderSchema)
 