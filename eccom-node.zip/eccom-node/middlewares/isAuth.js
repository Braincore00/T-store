module.exports = (req, res, next)=>{
    if(!req.session.isloginedIn){
        res.redirect('/login')
    }
    next()
}