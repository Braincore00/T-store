const express = require('express')
const {getadminlogin,getadminSignup,postadminSignup,getForgetPass,postForgetPass,getNewPassword,postNewPassword,postadminlogin,logout} = require('../controles/auth.js')
const router = express.Router()
const {body, check } = require("express-validator")

router.get('/login', getadminlogin)
router.get('/signup', getadminSignup)
router.post('/signup',[
    check("email").notEmpty().isEmail().withMessage('invalid email address'),
    body("password","invalid password").matches(/^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z])(?=.*[$#@]).{6,24}$/),
body("confirm-password","password does not match").custom((value, {req})=>{
    if(value !== req.body.password){
        throw new Error("password does not match")
    }
    return true
})],postadminSignup)
router.get('/forget-password',getForgetPass)
router.post('/reset', postForgetPass)
router.get('/reset/:token', getNewPassword)
router.post('/new-password', postNewPassword)
router.post('/login', postadminlogin)
router.post('/logout', logout)


module.exports = router