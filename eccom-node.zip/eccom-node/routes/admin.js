const express = require('express')
const {getProduct,getAddProduct,postAddProduct,getProductDetails,manageProducts,geteditProduct,posteditProduct,deleteProduct} = require('../controles/admin.js')
const router = express.Router()
const isAuth = require('../middlewares/isAuth.js')
 const {body} = require('express-validator')
 const upload = require('../middlewares/file-upload.js')
 
router.use((req, res, next)=>{
    if(req.session.role !== "admin"){
        res.redirect('/')
    }
    next()
})
router.get('/add-product',isAuth, getAddProduct)
router.post('/add-product',isAuth, 
// [body("title").notEmpty().isAlpha().withMessage('title should have alfabets only'),
// body("price").notEmpty().isNumeric(),
// body("weight").notEmpty().isNumeric().isLength({max: 5}),
// body("modelName").notEmpty(),
// body("description").notEmpty().isLength({min: 5, max: 20})],
upload.single("imageUrl"),postAddProduct)
router.get('/product-detail/:id',isAuth ,getProductDetails)
router.get('/manage-products',isAuth, manageProducts)
router.get('/edit-product/:id',isAuth ,geteditProduct)
router.post('/edit-product', isAuth,upload.single("imageUrl"),posteditProduct)
router.get('/delete-product/:id',isAuth ,deleteProduct)

module.exports = router
