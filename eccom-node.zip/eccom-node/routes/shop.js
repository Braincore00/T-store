const express = require('express')
const{getHomePage,getCart,about,productDetail,getShopProduct,shopProduct,upcart,updateCart,deleteItemFromCart,getCheckout,address,createOrder,postOrder,getCheckoutSuccess,getCheckoutCancel} = require('../controles/shop')
const isAuth = require('../middlewares/isAuth')
 
const router = express.Router()

router.get('/', getHomePage)
 router.use((req, res, next)=>{
   if(!req.session.isloginedIn){
    res.redirect('/login')
   }
   next()
 })
router.get('/shop/cart',isAuth, getCart)
router.post('/shop/cart',isAuth, upcart)
router.get('/about',isAuth, about)

router.get('/product-detail/:id',isAuth,productDetail)
router.get('/shop-list',isAuth,getShopProduct)
router.post('/shop-list',isAuth,shopProduct)
router.patch('/updateCart',isAuth, updateCart)
router.delete('/deleteItemFromCart/:id',isAuth,deleteItemFromCart)
router.get('/checkout',isAuth, getCheckout)
router.post('/address',isAuth,address)
router.get('/order/:id', isAuth,createOrder)
router.post('/checkout', isAuth, postOrder)
router.get('/checkout/success',isAuth, getCheckoutSuccess)
router.get('/checkout/cancel',isAuth, getCheckoutCancel)



module.exports = router