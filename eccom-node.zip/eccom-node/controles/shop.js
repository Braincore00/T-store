const stripe = require('stripe')('sk_test_51P4ELdSGgAvEiUpzSeR2oUcIDG3O3I5t74SbpJikSoXLdBeDO4PoJfoQBcUbPmtYIpGxYJLpdtUFgRvBK5TfJGV800vod1sD9Z')
const Product = require('../models/product')
const User = require('../models/user')
const Order = require('../models/order')
const { model } = require('mongoose')
const { response } = require('express')


exports.getHomePage = async (req, res, next) => {
  const products = await Product.find()
  res.render('shop/product', {
    path: '/',
    pageTitle: 'products',
    products: products,
  })
}

exports.getCart = async (req, res, next) => {
  const user = await req.user.populate('cart.productId')
  const product = user.cart;
  console.log(product);
  res.render('shop/cart', {
    pageTitle: 'your cart',
    product: product,
  })
}


exports.about =(req, res, next)=>{
  res.render('shop/about',{
    pageTitle : 'about'
  })
}
exports.productDetail = async(req, res,next)=>{
 const id =  req.params.id
 const product = await Product.findById(id)
  res.render('shop/product_detail',{
    pageTitle : 'product details',
    product: product,
  })
}
exports.getShopProduct = async(req, res,next)=>{
  
 const products = await Product.find()
  res.render('shop/shop-list',{
    pageTitle : 'product shoping',
    product: products,
  })
}
exports.shopProduct = async(req, res,next)=>{
  
 const products = await Product.find()
  
}

exports.upcart = async (req, res, next) => {
  const prodId = req.body.productId
  console.log(prodId);
  const respons = await req.user.addcart(prodId)
  // console.log(respons);
  res.redirect('/shop/cart')
}

exports.updateCart = async (req, res, next) => {
  console.log(req.body.prodId, req.body.qty);
  try {
    const response = await req.user.updateCartItem(req.body.prodId, req.body.qty)
    const product = response.cart.find((p) => {
      return p.productId.toString() === req.body.prodId
    })
    console.log(product);
    res.send({ updatedQty: product.quantity })



  } catch (err) {
    console.log(err);
  }

}

exports.deleteItemFromCart = async (req, res, next) => {
  const { id } = req.params
  const responce = await req.user.deleteProdFromCart(id)
  const user = await responce.populate('cart.productId');
  const updateCart = user.cart
  console.log(updateCart);
  res.send(updateCart)


}

exports.getCheckout = (req, res, next) => {
  const address = req.user.address
  res.render('shop/checkout', {
    pageTitle: 'checkout',
    address: address,

  })
}

exports.address = async (req, res, next) => {
  const data = req.body
  const responce = await req.user.addAddress(data)
  console.log(responce);
  res.redirect('/checkout')
}

exports.createOrder = async (req, res, next) => {
  const id = req.params.id
  console.log(id);
  const address = req.user.address.find((address) => address._id.toString() === id)
  console.log(address);
  const user = await req.user.populate('cart.productId')
  const product = user.cart;
  console.log(product);
  res.render('shop/order.ejs', {
    pageTitle: "order",
    products: product,
    address: address,

  })
  //   const user = await req.user.populate('cart.productId')
  //   const product = user.cart;
  //  console.log(product);
  // const products = user.cart.map((p)=>{
  //  return {quantity : p.quantity, productData: {...p.productId}}
  // })
  // const userId =  req.user._id

}

exports.postOrder = async (req, res, next) => {
  const id = req.body.addressId
  console.log(id);
  const address = req.user.address.find((address) => address._id.toString() === id)
  let total = 0;
  const user = await req.user.populate('cart.productId')
  const product = user.cart;
  product.forEach((p) => (total += p.quantity * p.productId.price))
  const session = await stripe.checkout.sessions.create({
    customer_data:{
    customer_name: address.name,
    customer_address : address,

    },
    line_items: product.map((p) => {
      return {
        
        price_data: {
          currency: "INR",
          product_data: {
            name: p.productId.title,
            description: p.productId.description,
          },
          unit_amount : p.productId.price * 100
        },
        quantity: p.quantity,
      }
    }),
    mode : "payment",
    success_url:"http://localhost:3000/checkout/success?productId=" +id,
    cancel_url : "http://localhost:3000/checkout/success",
  })
  res.redirect(303, session.url)

}

exports.getCheckoutSuccess = async (req, res, next) => {
  const id = req.query.addressId
  const address = req.user.address.find((address) => address._id.toString() === id)
  console.log(address);
  const user = await req.user.populate('cart.productId')
   
  const products = user.cart.map((p)=>{
     return {quantity : p.quantity, productData: {...p.productId}}
    })
    const userId =  req.user._id.toString()
  const order = new Order({
    address : address,
    userId : userId,
    products : products
  })
  order.save().then((response)=>{
    req.user.clearCart().then(()=>{
      res.render('shop/thank-you-page', {
        pageTitle: "thankyou"
      })

    })
  })
}


exports.getCheckoutCancel = (req, res, next) => {
  res.render('shop/cancel', {
    pageTitle: "thankyou"
  })
}
