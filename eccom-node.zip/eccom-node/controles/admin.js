const Product = require('../models/product')
const { validationResult } = require('express-validator')
const fs = require('fs/promises')

exports.getAddProduct = (req, res, next) => {
    res.render('admin/add-product', {
        pageTitle: 'Tstore- Admin Dashboard',
        path: '/admin/add-product',
        editable: false,
        errrMasage: req.flash("error")
    })
}

exports.postAddProduct = (req, res, next) => {
    const { title, imageUrl, price, weight, modelName, description } = req.body
    console.log(req.file);
    if (!req.file) {
        req.flash("error", "invalid file type")
        res.redirect('/admin/add-product')
    }
    const error = validationResult(req)
    if (!error.isEmpty()) {
        return res.render('admin/add-product', {
            pageTitle: 'Tstore- Admin Dashboard',
            path: '/admin/add-product',
            editable: false,
            errrMasage: error.array()[0].msg
        })
    }
    console.log({ title, imageUrl, price, weight, modelName, description });
    Product.create({ title, imageUrl: req.file.path, price, weight, modelName, description })
    res.redirect('/admin/manage-products')
}

exports.getProductDetails = async (req, res, next) => {
    const id = req.params.id

    const product = await Product.findById(id)
    //  console.log(product);
    res.render('admin/produt-admin-detail', {
        path: '/admin/product-detail',
        pageTitle: 'product Details',
        product: product,
    })
}

exports.manageProducts = async (req, res, next) => {
    Product.find().then((product) => {
        res.render('admin/manageProduct', {
            path: '/admin/manage-products',
            pageTitle: 'Manage Products',
            products: product,
        })

    })
}

exports.geteditProduct = async (req, res, next) => {
    const id = req.params.id
    const editable = req.query.edit
    const product = await Product.findById(id)
    res.render('admin/add-product', {
        pageTitle: 'Tstore- Admin Dashboard',
        path: '/admin/edit-product',
        editable: editable,
        product: product,
        errrMasage: req.flash("error")
    })

}
exports.posteditProduct = async (req, res, next) => {
    const { title, price, weight, modelName, description, productId } = req.body
    console.log(req.body);
    const product = await Product.findById(productId)
 console.log(req.file);
 console.log(product);
 
    try {
        if (req.file) {
            await fs.unlink(product.imageUrl)
        }

    } catch (err) {
        console.log(err);
    }
    try {
        await Product.findByIdAndUpdate(productId,
            {
                title,
                imageUrl: req.file ? req.file.path : product.imageUrl,
                price,
                weight,
                modelName,
                description
            })
        res.redirect('/admin/manage-products')

    } catch (err) {
        console.log(err.message);
    }
}

exports.deleteProduct = async (req, res, next) => {

    const id = req.params.id
    const productpath = await Product.findById(id)

   await fs.unlink(productpath.imageUrl, (err) => {
        if (err) {
            console.log(err);
        } 
    })
    Product.findByIdAndDelete(id).then(() => {
        res.redirect('/admin/manage-products')

    })
    
    
        

}