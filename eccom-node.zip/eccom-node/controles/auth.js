const User = require('../models/user')
const bcrypt = require('bcryptjs')
const nodemailer = require('nodemailer')
const crypto = require('crypto')
const { error } = require('console')

const {validationResult} = require('express-validator')

 
 
const transporter = nodemailer.createTransport({
    service : "Gmail",
    auth : {
        user : 'braincore67@gmail.com',
        pass : 'eanstydcnzixadvs'
    }
})

exports.getadminlogin =(req, res, next) =>{
    res.render('auth/login',{
        pageTitle : 'login page',
        errrMasage : req.flash("error"),
        errrMasage2 : req.flash('error')

        
    })
       
    
        
}
exports.getadminSignup = (req, res,next)=>{
    res.render('auth/signup',{
        pageTitle : 'signup page',
        errrMasage : req.flash('error')
       
    })
}
exports.postadminSignup = async(req, res, next) =>{
    const{username, email, password} = req.body
    const error = validationResult(req)

    if(!error.isEmpty()){
      return res.render('auth/signup',{
            pageTitle : 'signup page',
            errrMasage :  error.array()[0].msg
           
        })
        
    }
    
 //    console.log({username, email, password});
    const user =  await User.findOne({email : email})
 //    console.log(user);
 if(user){
     req.flash("error", "email alrady added please defrent email and username")
    return res.redirect('/singup')
 }
 let hashPassword;
 try{
      hashPassword = await bcrypt.hash(password, 12)
     
     
 }catch(err){
 console.log('enable to create user');
 return next(err)
 }
 try{
     const user = await User.find()
     if(user.length == 0){
         await User.create({username : username, email : email, password : hashPassword, role : 'admin'}) 
     }
     else{
 
         await User.create({username : username, email : email, password : hashPassword , role : 'cutomer'}) 
     }
 
 }catch(err){
     console.log('enable to cart');
    return next(err)
 }
 
 try{
     const sentmail = await transporter.sendMail({
         from : 'braincore67@gmail.com',
         to : email,
         subject : 'signup succesfull',
         html : '<h1>your are succesfully signup</h1>'
          
     })
     if(sentmail){
         res.redirect('/login')
     }
 
 }catch(err){
     console.log('unebale to send mail');
     return next(err)
 }
 }
 
exports.getForgetPass = (req, res, next) =>{
res.render('auth/forget-password',{
    pageTitle : 'forget password',
    path : '/forget-password',
    errrMasage : req.flash("error"),
})
}

exports.postForgetPass = async (req, res, next) =>{
const email = req.body.email
 
try{
    const user = await User.findOne({email : email})
     
    if(!user){
        req.flash("error", "!invaled email address")
       return res.redirect('/forget-password')
    }
crypto.randomBytes(32,(err, buffer)=>{
    if(err){
        console.log(err);
        return
    }
   const token =  buffer.toString('hex')
  
   user.resetToken = token;
   user.resetTokenExpiration = Date.now() + 3600000;
   user.save ().then(()=>{
      return transporter.sendMail({
        from : 'braincore67@gmail.com',
        to : email,
        subject : ' reset password',
        html : `<h1>you have requesed for password reset</h1>
        <p>click on this link <a href='http://localhost:3000/reset/${token}'> to update password </a></p>`
         
    })
   })
})

}catch(err){
    return next(err)

}
}

exports.getNewPassword = async(req, res, next)=>{
    const Newtoken = req.params.token
    console.log(Newtoken);

   const user = await User.findOne({resetToken : Newtoken, resetTokenExpiration : {$gt : Date.now()},})
   console.log(user);
   if(!user){
    
   return res.redirect('/reset')
   }
   res.render('auth/new-password',{
    pageTitle : 'new password',
    path : '/new-password',
    token :  Newtoken,
    userId : user._id,
    errrMasage : req.flash("error")
   })
}

exports.postNewPassword = async (req, res, next) =>{
    const {password, token, userId } = req.body
    const user = await User.findOne({resetToken : token, resetTokenExpiration : {$gt : Date.now()},})
 
   if(!user){
    req.flash("error", "!session time out")
   return res.redirect('/reset')
   }
   let hashPassword;
   try{
        hashPassword = await bcrypt.hash(password, 12)
       
       
   }catch(err){
   console.log('enable to create user');
   return next(err)
   }
   try{
       await User.findByIdAndUpdate(userId,
        {password : hashPassword,resetToken :null, resetTokenExpiration :null})
       res.redirect('/login')
   
   }catch(err){
       console.log('enable to cart');
      return next(err)
   }
   
     
}

exports.postadminlogin = async (req, res, next) =>{
    const {username, password} = req.body
    console.log({username, password});
 const user =   await User.findOne({username : username})
 if(!user){
    req.flash("error", "!invalid user name please signup")
    console.log('invalid user name please signup'); 
   return  res.redirect('/login')
 }
 try{
     const matchinpass = await bcrypt.compare(password , user.password )
     if(matchinpass){
        // req.isloginedIn = true
        // res.setHeader('Set-Cookie','isloginedIn = ture')
        req.session.isloginedIn =  true
        req.session.user = user._id
        req.session.role = user.role
        req.session.save(()=>{
            return res.redirect('/')

        }) 

      

     }else{
        req.flash("error", "!invalid password  please reset password")
         res.redirect('/login')

     }
 
 }catch(err){
    console.log('server error');
    return next(err)

 }
}

exports.logout = (req, res, next)=>{
    req.session.destroy(()=>{
        res.redirect('/login')
    })
}