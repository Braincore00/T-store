const pickImageHandler = ()=>{
    document.querySelector('#imageUrl').click()
}

const pickedhandler = (e)=>{
   if(e.target.files.length > 0){
    const filePick = e.target.files[0]
   const fileReeader =  new FileReader()
   fileReeader.onload = ()=>{
    document.querySelector('.image-upload__preview img').src = fileReeader.result
   }
   fileReeader.readAsDataURL(filePick)

   } 
   else{
    return false
   } 

}