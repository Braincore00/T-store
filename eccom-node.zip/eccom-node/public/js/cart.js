
const updateQty = async (qty, prodId, event) => {
    console.log(event.target);
    // console.log(qty, prodId);
    const proDect = {
        qty: qty,
        prodId: prodId,
    }

    const response = await fetch("/updateCart", {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(proDect)

    })
    const data = await response.json();
    if (response.ok) {

    } else {
        alert(response.statusText)
    }


    event.target.parentElement.children[1].innerHTML = data.updatedQty
}

const deleteProduct = async (e)=>{
    e.preventDefault()
const prodId =  e.target.productID.value;
 const response = await fetch(`/deleteItemFromCart/${prodId}`,{
    method : 'DELETE',
 })

 const data = await response.json()
 if (response.ok) {
 const request = new XMLHttpRequest()
 request.open('GET','/shop/cart')
 request.onload = ()=>{
    console.log(request.responseText.split("<main>")[1]);
    document.querySelector('main').innerHTML = request.responseText.split('<main>')[1]
 }
request.send()

}else{
    alert(response.status)
}

}